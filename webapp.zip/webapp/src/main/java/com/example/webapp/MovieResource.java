package com.example.webapp;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter @NoArgsConstructor
public class MovieResource {
    private Movie movie;
}
