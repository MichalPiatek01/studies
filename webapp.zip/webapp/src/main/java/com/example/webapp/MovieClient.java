package com.example.webapp;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient (name = "movie-client", url = "http://www.omdbapi.com/")
public interface MovieClient {

    @GetMapping
    MovieResource getMovie(@RequestParam("t") String title, @RequestParam("apikey") String apiKey);
}
