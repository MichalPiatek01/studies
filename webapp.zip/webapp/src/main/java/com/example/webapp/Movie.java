package com.example.webapp;

import lombok.Getter;
import lombok.NoArgsConstructor;
@Getter @NoArgsConstructor
public class Movie {
    private String titleFromResponse;
    private String year;
    private String rated;
    private String released;
    private String runtime;
    private String genre;
    private String director;
    private String writer;
    private String actors;
    private String plot;
    private String language;
    private String country;
    private String awards;
    private String poster;
    private String metascore;
    private String imdbRating;
}
