package com.example.webapp;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service @Getter
public class MovieService {

    private final MovieClient movieClient;

    @Autowired
    public MovieService(MovieClient movieClient) {
        this.movieClient = movieClient;
    }

    public String getPlotByTitle(String title, String apiKey) {
        char replacement = '+';
        title = title.replace(' ', replacement);
        MovieResource movieResource = movieClient.getMovie(title, apiKey);
        if (movieResource != null && movieResource.getMovie() != null) {
            return movieResource.getMovie().getPlot();
        }
        return null;
    }
}
