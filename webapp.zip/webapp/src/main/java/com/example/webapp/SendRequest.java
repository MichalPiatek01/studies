package com.example.webapp;

import lombok.Getter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;
@Getter
public class SendRequest {
    private String titleFromResponse;
    private String year;
    private String rated;
    private String released;
    private String runtime;
    private String genre;
    private String director;
    private String writer;
    private String actors;
    private String plot;
    private String language;
    private String country;
    private String awards;
    private String poster;
    private String metascore;
    private String imdbRating;
    public SendRequest(String title) {
        try {
            char replacement = '+';
            title = title.replace(' ', replacement);
            URL url = new URL("http://www.omdbapi.com/?t=" + title + "&apikey=8bc18b62");
            System.out.println(url);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            // Check if connect is made
            int responseCode = conn.getResponseCode();

            // 200 Ok
            if (responseCode != 200) {
                throw new RuntimeException("HttpResponseCode: " + responseCode);
            } else {
                StringBuilder informationString = new StringBuilder();
                Scanner scanner = new Scanner(url.openStream());

                while (scanner.hasNext()) {
                    informationString.append(scanner.nextLine());
                }

                scanner.close();

                System.out.println(informationString);

                JSONObject jsonObject = new JSONObject(informationString.toString());
                this.titleFromResponse = jsonObject.getString("Title");
                this.year = jsonObject.getString("Year");
                this.rated = jsonObject.getString("Rated");
                this.released = jsonObject.getString("Released");
                this.runtime = jsonObject.getString("Runtime");
                this.genre = jsonObject.getString("Genre");
                this.director = jsonObject.getString("Director");
                this.writer = jsonObject.getString("Writer");
                this.actors = jsonObject.getString("Actors");
                this.plot = jsonObject.getString("Plot");
                this.language = jsonObject.getString("Language");
                this.country = jsonObject.getString("Country");
                this.awards = jsonObject.getString("Awards");
                this.poster = jsonObject.getString("Poster");
                this.metascore = jsonObject.getString("Metascore");
                this.imdbRating = jsonObject.getString("imdbRating");
            }

        } catch (MalformedURLException e) {
            System.out.println("Wrong URL format");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}