package com.example.webapp;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.component.button.Button;
import lombok.Setter;

@Route(value ="")
@Setter
public class MainView extends VerticalLayout {
    TextField searchField = new TextField();
    Div infoDiv = new Div();
    Div titleDiv = new Div();
    Div yearDiv = new Div();
    private final MovieService movieService;
    public MainView(MovieService movieService) {
        this.movieService = movieService;
        add(getSearchbar(), titleDiv, yearDiv, infoDiv);
    }

    public HorizontalLayout getSearchbar() {
        searchField.setPlaceholder("Search by movie name");
        searchField.setClearButtonVisible(true);

        Button searchButton = new Button("Search");
        searchButton.addClickListener(event -> searchMovie());
        searchButton.addClickShortcut(Key.ENTER);

        var searchbar = new HorizontalLayout(searchField,searchButton);
        searchbar.addClassName("searchbar");
        return searchbar;
    }
    private void searchMovie(){
        titleDiv.removeAll();
        yearDiv.removeAll();
        String searchString = searchField.getValue();
        SendRequest sendRequest = new SendRequest(searchString);
        infoDiv.setText("Genre: " + sendRequest.getGenre() + "<br>" +
                "Director: " + sendRequest.getDirector() + "<br>" +
                "Writer: " + sendRequest.getWriter() + "<br>" +
                "Actors: " + sendRequest.getActors() + "<br>" +
                "Plot: " + sendRequest.getPlot() + "<br>" +
                "Language: " + sendRequest.getLanguage() + "<br>" +
                "Country: " + sendRequest.getCountry() + "<br>" +
                "Awards: " + sendRequest.getAwards() + "<br>" +
                "Metascore: " + sendRequest.getMetascore() + "<br>" +
                "IMDB Rating: " + sendRequest.getImdbRating() + "<br>");

        // Display poster image
        Image posterImage = new Image(sendRequest.getPoster(), "Poster");
        posterImage.setWidth("300px"); // Set width of the image
        infoDiv.add(posterImage); // Add the image to the infoDiv
        titleDiv.add(sendRequest.getTitleFromResponse() + movieService.getPlotByTitle("Guardians of the Galaxy", "8bc18b62"));
        yearDiv.add(sendRequest.getYear() + " " + sendRequest.getRated() + " " + sendRequest.getRuntime());
    }


}